# import  shubham 
# shubham.add (10, 20)
# shubham.sub (22,11)
# print(shubham.n1)

# import  shubham  as s
# s.add (10, 20)
# s.sub (22,11)
# print(s.n1)

# from shubham import add, sub, n1 
# add (10, 20)
# sub (22,11)
# print(n1)

# from shubham import *
# add (10, 20)
# sub (22,11)
# print(n1)


from packages.arithmatic.shubham import *
add (10, 20)
sub (22,11)
print(n1)


