# f = open("child.txt", "w")
# f.write("I am a child file, created by file.py")   
# print("Write operation is performed successfully") 
# f.close()


# f = open("child.txt", "w")
# l = ["Shubham\n", "Kapil\n", "Chirag\n", "Sonu\n"]
# f.writelines(l)   
# print("Write operation is performed successfully") 
# f.close()

#Read data from text files
# f=open("child.txt", 'r')
# data=f.read()
# print(data)
# f.close()

# #read no of character
# f=open("child.txt", 'r')
# data=f.read(12)
# print(data)
# f.close()

# #read line by line
# f=open("child.txt", 'r')
# data=f.readlines()
# for x in data:
#     print(x, end='')
# f.close()

#read image and write new image
# f1=open ("shubham.jpg", "rb" )
# f2=open ("newshubham.jpg", "wb" )
# bytes=f1.read()
# f2.write(bytes)
# print(bytes)
# print("New image is available")

# write data in csv file
# import csv
# with open("emp.csv", "w", newline='') as f:
#     w=csv.writer(f)
#     w.writerow(["ENO", "ENAME", "ESALARY", "EADDR" ])
#     n=int(input("Enter number of employees : "))
#     for i in range(n):
#         eno=input("Enter employee no : ")
#         ename=input("Enter employee name : ")
#         esal=input("Enter employee salary : ")
#         eaddr=input("Enter employee address : ")
#         w.writerow([eno, ename, esal, eaddr])
# print("Data inserted successfully!")


# read data from csv file
import csv
with open("emp.csv", "r") as f:
    r=csv.reader(f)
    data=list(r)
    for line in data:
        for word in line:
            print(word, end=' ')
        print()
